KIYAAKU — GOOGLE READY

Upload/ganti 3 file berikut di repository KiyaAku:
- index.html
- robots.txt
- sitemap.xml

Setelah commit:
1. Buka Google Search Console: https://search.google.com/search-console/
2. Tambahkan URL prefix: https://giiboo27-cmd.github.io/KiyaAku/
3. Verifikasi kepemilikan.
4. Buka Sitemaps dan masukkan: sitemap.xml
5. Gunakan URL Inspection untuk URL utama dan pilih Request Indexing bila tersedia.

Catatan: Google tidak menjamin halaman langsung muncul. Crawling/indexing dapat membutuhkan waktu.
